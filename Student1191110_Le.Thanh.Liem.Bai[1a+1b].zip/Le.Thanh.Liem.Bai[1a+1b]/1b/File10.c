#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX 1024

int main() {
    int claim_count[MAX];
    int max;
    FILE *f;
    char inputfile[] = "file1.txt";
    f = fopen(inputfile, "r");
        if (f == NULL) exit(1);

    char s[MAX];
    fgets(s, MAX, f);
    int N; N = atoi(s);

    for(int i = 0; i < N; i++) {
        fscanf(f, "%d", &claim_count[i]);
    }
    max = claim_count[0];
    for(int i = 0; i < N; i++) {
        if(claim_count[i] > max) max = claim_count[i];
        else continue;
    }
    for(int i = 0; i < N; i++) {
        if(claim_count[i] == max) claim_count[i] = 1;
        else claim_count[i] = 0;
    }
    fclose(f);

    FILE* f2; char outputfile[] = "output.txt";
    f2 = fopen(outputfile, "w");
        if (f2 == NULL) exit(1);
    for(int i = 0; i < N; i++) {
        fprintf(f2, "%d\n", claim_count[i]);
    }
    fclose(f2);
    return 0;
}

