#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX 1024

int main() {
    float p[MAX];
    float min;
    FILE *f;
    char inputfile[] = "file1.txt";
    f = fopen(inputfile, "r");
        if (f == NULL) exit(1);

    for (int i = 0; i < 6; i++) {
        fscanf(f, "%f", &p[i]);
    }
    min = p[0];
    for(int i = 1; i < 6; i++) {
        if(p[i] < min) min = p[i];
    }
    fclose(f);

    FILE* f2;
    char outputfile[] = "output.txt";
    f2 = fopen(outputfile, "w");
        if (f2 == NULL) exit(1);
    fprintf(f2, "%.3f", min);

    return 0;

}
